# Copyright (C) 2019 - TODAY, Gray Matter Logic
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from datetime import timedelta
from unittest.mock import patch

from odoo import Command, fields
from odoo.exceptions import UserError, ValidationError
from odoo.fields import Domain
from odoo.tests import Form
from odoo.tools import mute_logger

from .test_fsm_common import FSMCommon

TEST_IMAGE_BASE64 = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAACklEQVR4nGP4DwABAQEAGN2N9wAAAABJRU5ErkJggg=="  # noqa: E501


class TestFSMOrder(FSMCommon):
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Order = cls.env["fsm.order"]
        cls.stage1 = cls.env.ref("fieldservice.fsm_stage_completed")
        cls.stage2 = cls.env.ref("fieldservice.fsm_stage_cancelled")
        cls.init_values = {
            "stage_id": cls.env.ref("fieldservice.fsm_stage_completed").id
        }
        cls.init_values_2 = {
            "stage_id": cls.env.ref("fieldservice.fsm_stage_cancelled").id
        }
        today = fields.Datetime.today()
        start_date = today + timedelta(days=1)
        date_end = start_date.replace(hour=23, minute=59, second=59)
        cls.p_leave = cls.env["resource.calendar.leaves"].create(
            {
                "date_from": start_date,
                "date_to": date_end,
            }
        )
        cls.tag = cls.env["fsm.tag"].create({"name": "Test Tag"})
        cls.tag1 = cls.env["fsm.tag"].create(
            {"name": "Test Tag1", "parent_id": cls.tag.id}
        )
        cls.order = cls.env["fsm.order"].create(
            {
                "location_id": cls.test_location.id,
                "date_start": fields.Datetime.today(),
                "date_end": fields.Datetime.today() + timedelta(hours=10),
                "request_early": fields.Datetime.today(),
            }
        )

    def test_fsm_order_default_stage(self):
        view_id = "fieldservice.fsm_order_form"
        stage_ids = self.env["fsm.stage"].search(
            domain=Domain.AND(
                [
                    Domain("stage_type", "=", "order"),
                    Domain("is_default", "=", True),
                    Domain("company_id", "in", (self.env.user.company_id.id, False)),
                ]
            ),
            order="sequence asc",
        )
        for stage in stage_ids:
            stage.unlink()
        with self.assertRaises(ValidationError):
            Form(self.Order, view=view_id)

    def test_fsm_order_default_team(self):
        view_id = "fieldservice.fsm_order_form"
        with mute_logger("odoo.models.unlink"):
            self.order.unlink()
            self.env["fsm.team"].search([]).unlink()
        with self.assertRaisesRegex(
            ValidationError, "You must create an FSM team first."
        ):
            Form(self.Order, view=view_id)

    def test_fsm_order_default_team_from_location(self):
        """The default team for an order comes from its location."""
        # Arrange
        team_form = Form(self.env["fsm.team"])
        team_form.name = "Test team"
        team = team_form.save()
        location = self.test_location
        location.team_id = team
        # pre-condition
        self.assertNotEqual(team, self.Order._default_team_id())

        # Act
        order_form = Form(self.Order)
        order_form.location_id = location
        order = order_form.save()

        # Assert
        self.assertEqual(order.team_id, team)

    def test_fsm_order_create(self):
        priority_vs_late_days = {"0": 3, "1": 2, "2": 1, "3": 1 / 3}
        vals = {
            "location_id": self.test_location.id,
            "stage_id": self.stage1.id,
        }
        for priority, _late_days in priority_vs_late_days.items():
            vals.update({"priority": priority})
            self.env["fsm.order"].create(vals)
            vals2 = {
                "request_early": fields.Datetime.today(),
                "location_id": self.test_location.id,
                "priority": priority,
                "scheduled_date_start": fields.Datetime.today().replace(
                    hour=0, minute=0, second=0
                ),
            }
            order_vals = {
                "request_early": fields.Datetime.today(),
                "location_id": self.test_location.id,
                "priority": priority,
                "scheduled_date_start": fields.Datetime.today().replace(
                    hour=0, minute=0, second=0
                ),
            }
            self.env["fsm.order"].create(order_vals)
            order = self.env["fsm.order"].create(vals2)
            order.write(
                {
                    "scheduled_date_start": order.request_early.replace(
                        hour=0, minute=0, second=0
                    ),
                    "scheduled_date_end": order.scheduled_date_start
                    + timedelta(hours=10),
                }
            )
            with self.assertRaises(ValidationError):
                order.write(
                    {
                        "scheduled_date_start": order.request_early.replace(
                            hour=0, minute=0, second=0
                        ),
                        "scheduled_date_end": order.scheduled_date_start
                        + timedelta(hours=100),
                    }
                )
            # report
            res = self.env["ir.actions.report"]._render_qweb_text(
                "fieldservice.report_fsm_order", order.ids
            )
            self.assertRegex(str(res[0]), order.name)

    def test_fsm_order(self):
        """Test creating new workorders, and test following functions,
        - _compute_duration() in hrs
        - _compute_request_late()
        - Set scheduled_date_start using request_early w/o time
        - scheduled_date_end = scheduled_date_start + duration (hrs)
        """
        # Create an Orders
        view_id = "fieldservice.fsm_order_form"
        hours_diff = 100
        with Form(self.Order, view=view_id) as f:
            f.location_id = self.test_location
            f.date_start = fields.Datetime.today()
            f.date_end = f.date_start + timedelta(hours=hours_diff)
            f.request_early = fields.Datetime.today()
        order = f.save()
        with Form(self.Order, view=view_id) as f:
            f.location_id = self.test_location
            f.date_start = fields.Datetime.today()
            f.date_end = f.date_start + timedelta(hours=80)
            f.request_early = fields.Datetime.today()
        order2 = f.save()
        order._get_stage_color()
        view_id = "fieldservice.fsm_equipment_form_view"
        with Form(self.env["fsm.equipment"], view=view_id) as f:
            f.name = "Equipment 1"
            f.current_location_id = self.test_location
            f.location_id = self.test_location
            f.notes = "test"
        equipment = f.save()
        order3 = self.Order.create(
            {
                "location_id": self.test_location.id,
                "stage_id": self.stage1.id,
            }
        )
        order4 = self.Order.create(
            {
                "location_id": self.test_location.id,
                "stage_id": self.stage2.id,
            }
        )
        self.init_values2 = {}
        self.tag._compute_full_name()
        self.tag1._compute_full_name()
        config = self.env["res.config.settings"].create({})
        config.group_fsm_equipment = False
        config.auto_populate_equipments_on_order = True
        config._onchange_group_fsm_equipment()
        self.assertFalse(config.auto_populate_equipments_on_order)
        config.module_fieldservice_repair = False
        config._onchange_module_fieldservice_repair()
        config.module_fieldservice_repair = True
        config._onchange_module_fieldservice_repair()
        self.assertTrue(config.group_fsm_equipment)
        order3._track_subtype(self.init_values)
        order4._track_subtype(self.init_values)
        order3._track_subtype(self.init_values_2)
        order4._track_subtype(self.init_values_2)
        order4._track_subtype(self.init_values2)
        order4.action_complete()
        order3.action_cancel()
        self.env.user.company_id.auto_populate_equipments_on_order = True
        self.assertEqual(order.custom_color, order.stage_id.custom_color)
        # Test _compute_duration
        self.assertEqual(order.duration, hours_diff)
        # Test request_late
        priority_vs_late_days = {"0": 3, "1": 2, "2": 1, "3": 1 / 3}
        for priority, late_days in priority_vs_late_days.items():
            order_test = self.Order.create(
                {
                    "location_id": self.test_location.id,
                    "request_early": fields.Datetime.today(),
                    "priority": priority,
                }
            )
            self.assertEqual(
                order_test.request_late, order.request_early + timedelta(days=late_days)
            )
        # Test scheduled_date_start is not automatically set
        self.assertEqual(order.scheduled_date_start, False)
        # Test scheduled_date_end = scheduled_date_start + duration (hrs)
        # Set date start
        order.scheduled_date_start = fields.Datetime.now().replace(
            hour=0, minute=0, second=0
        )

        # Set duration
        duration = 10
        order.scheduled_duration = duration
        order.onchange_scheduled_duration()
        # Check date end
        self.assertEqual(
            order.scheduled_date_end,
            order.scheduled_date_start + timedelta(hours=duration),
        )
        # Set new date end
        order.scheduled_date_end = order.scheduled_date_end.replace(
            hour=1, minute=1, second=0
        )
        order.onchange_scheduled_date_end()
        # Check date start
        self.assertEqual(
            order.scheduled_date_start,
            order.scheduled_date_end - timedelta(hours=duration),
        )
        view_id = "fieldservice.fsm_location_form_view"
        with Form(self.env["fsm.location"], view=view_id) as f:
            f.name = "Child Location"
            f.parent_id = self.test_location
        location = f.save()
        self.test_team = self.env["fsm.team"].create({"name": "Test Team"})
        order_type = self.env["fsm.order.type"].create(
            {"name": "Test Type", "internal_type": "fsm"}
        )
        order.type = order_type.id
        stage = self.env["fsm.stage"]
        stage.get_color_information()
        with self.assertRaises(ValidationError):
            self.stage2.custom_color = "ECF0F1"
        with self.assertRaises(ValidationError):
            stage.create(
                {
                    "name": "Test",
                    "stage_type": "order",
                    "sequence": 10,
                }
            )
        order.description = "<p>Description</p>"
        order.equipment_ids = equipment
        self.assertEqual(
            order.description, "<p>Description</p>", "Shouldn't have changed"
        )
        order.description = False
        equipment.notes = "<p>Equipment notes</p>"
        order.equipment_ids = equipment
        self.assertEqual(
            order.description,
            equipment.notes,
            "Description should be set from equipment",
        )
        order.type = False
        order.description = False
        self.location_1.direction = "Test Direction"
        order2.location_id = location
        order2.location_id.parent_id = self.location_1.id
        data = (
            self.env["fsm.order"]
            .with_context(**{"default_team_id": self.test_team.id})
            .with_user(self.env.user)
            ._read_group(
                domain=Domain("id", "=", order.id),
                groupby=["stage_id"],
                aggregates=["__count"],
            )
        )
        self.assertTrue(data, "It should be able to read group")
        order.can_unlink()
        order.unlink()

    def test_order_move_to_completed(self):
        """Test move to completed

        An order can't be moved to Completed directly from Kanban or Status bar.
        Instead, it should go through the "Complete" button (action_complete).
        """
        # Can't move to completed directly
        with self.assertRaisesRegex(UserError, "Cannot move to completed from Kanban"):
            self.order.stage_id = self.stage1
        # Instead, it should go through the "Complete" button (action_complete).
        self.order.action_complete()
        self.assertEqual(self.order.stage_id, self.stage1)

    def test_order_unlink(self):
        with self.assertRaises(ValidationError):
            order = self.Order.create(
                {
                    "location_id": self.test_location.id,
                    "stage_id": self.stage1.id,
                }
            )
            order.stage_id.stage_type = "location"
            order.can_unlink()
            order.unlink()

    def test_order_sign(self):
        order = self.Order.create(
            {
                "location_id": self.test_location.id,
                "stage_id": self.stage1.id,
            }
        )
        order.stage_id.require_signature = True
        # Sign it
        Wizard = self.env["fsm.order.sign.wizard"].with_context(
            active_model=order._name, active_id=order.id
        )
        with Form(Wizard) as wizard_form:
            wizard_form.signed_by = "Test Customer"
            wizard_form.signature = TEST_IMAGE_BASE64

        now = fields.Datetime.now()
        with patch("odoo.fields.Datetime.now", return_value=now):
            wizard_form.record.action_sign()
        # Check that the signature has been updated
        self.assertEqual(order.signed_by, "Test Customer")
        self.assertEqual(order.signed_on, now)

    def test_equipment_removed_on_company_mismatch(self):
        """Equipments from another company are dropped on company change."""
        company2 = self.env["res.company"].create({"name": "FSM Other Company"})
        equipment = self.env["fsm.equipment"].create(
            {
                "name": "Company Mismatch Equipment",
                "current_location_id": self.test_location.id,
                "location_id": self.test_location.id,
                "company_id": self.env.company.id,
            }
        )
        order = self.Order.create(
            {
                "location_id": self.test_location.id,
                "equipment_ids": [Command.set(equipment.ids)],
            }
        )
        self.assertIn(equipment, order.equipment_ids)
        order.company_id = company2
        self.assertFalse(order.equipment_ids)

    def test_onchange_template_without_type_or_team(self):
        template = self.env["fsm.template"].create(
            {"name": "Bare Template", "duration": 2.5}
        )
        order = self.Order.new(
            {"location_id": self.test_location.id, "template_id": template.id}
        )
        order._onchange_template_id()
        self.assertEqual(order.scheduled_duration, 2.5)
