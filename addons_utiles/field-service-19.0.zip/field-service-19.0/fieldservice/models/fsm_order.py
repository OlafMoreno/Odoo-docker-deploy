# Copyright (C) 2018 Gray Matter Logic
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from datetime import datetime, timedelta

from markupsafe import Markup

from odoo import Command, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.fields import Domain

from . import fsm_stage


class FSMOrder(models.Model):
    _name = "fsm.order"
    _description = "Field Service Order"
    _inherit = ["mail.thread", "mail.activity.mixin"]

    def _default_stage_id(self):
        stage = self.env["fsm.stage"].search(
            domain=Domain.AND(
                [
                    Domain("stage_type", "=", "order"),
                    Domain("is_default", "=", True),
                    Domain("company_id", "in", (self.env.company.id, False)),
                ]
            ),
            order="sequence asc",
            limit=1,
        )
        if stage:
            return stage
        raise ValidationError(self.env._("You must create an FSM order stage first."))

    def _default_team_id(self):
        team = self.env["fsm.team"].search(
            domain=Domain("company_id", "in", (self.env.company.id, False)),
            order="sequence asc",
            limit=1,
        )
        if team:
            return team
        raise ValidationError(self.env._("You must create an FSM team first."))

    @api.depends(
        "location_id",
    )
    def _compute_team_id(self):
        cached_teams = dict()
        for order in self:
            team = order.location_id.team_id
            if not team:
                order_key = order.env.company
                team = cached_teams.get(order_key)
                if not team:
                    team = cached_teams[order_key] = order._default_team_id()

            order.team_id = team

    def _default_request_early(self):
        return fields.Datetime.now().replace(second=0)

    @api.depends("date_start", "date_end")
    def _compute_duration(self):
        for rec in self:
            duration = 0.0
            if rec.date_start and rec.date_end:
                start = fields.Datetime.from_string(rec.date_start)
                end = fields.Datetime.from_string(rec.date_end)
                delta = end - start
                duration = delta.total_seconds() / 3600
            rec.duration = duration

    @api.depends("stage_id")
    def _get_stage_color(self):
        """Get stage color"""
        self.custom_color = self.stage_id.custom_color or "#FFFFFF"

    def _track_subtype(self, init_values):
        self.ensure_one()
        if "stage_id" in init_values:
            if self.stage_id.id == self.env.ref("fieldservice.fsm_stage_completed").id:
                return self.env.ref("fieldservice.mt_order_completed")
            elif (
                self.stage_id.id == self.env.ref("fieldservice.fsm_stage_cancelled").id
            ):
                return self.env.ref("fieldservice.mt_order_cancelled")
        return super()._track_subtype(init_values)

    stage_id = fields.Many2one(
        "fsm.stage",
        string="Stage",
        tracking=True,
        index=True,
        copy=False,
        group_expand="_read_group_stage_ids",
        default=lambda self: self._default_stage_id(),
    )
    is_closed = fields.Boolean(
        "Is closed",
        related="stage_id.is_closed",
    )
    priority = fields.Selection(
        fsm_stage.AVAILABLE_PRIORITIES,
        index=True,
        default=fsm_stage.AVAILABLE_PRIORITIES[0][0],
    )
    tag_ids = fields.Many2many(
        "fsm.tag",
        "fsm_order_tag_rel",
        "fsm_order_id",
        "tag_id",
        string="Tags",
        help="Classify and analyze your orders",
    )
    color = fields.Integer("Color Index", default=0)
    team_id = fields.Many2one(
        "fsm.team",
        string="Team",
        compute="_compute_team_id",
        precompute=True,
        store=True,
        readonly=False,
        index=True,
        required=True,
        tracking=True,
    )

    # Request
    name = fields.Char(
        required=True,
        index=True,
        copy=False,
        default=lambda self: self.env._("New"),
    )

    location_id = fields.Many2one(
        "fsm.location", string="Location", index=True, required=True
    )
    location_directions = fields.Html(
        compute="_compute_location_directions",
        precompute=True,
        store=True,
        readonly=False,
    )
    request_early = fields.Datetime(
        string="Earliest Request Date",
        default=lambda self: self._default_request_early(),
    )
    color = fields.Integer("Color Index")
    company_id = fields.Many2one(
        "res.company",
        string="Company",
        required=True,
        index=True,
        default=lambda self: self.env.company,
        help="Company related to this order",
    )

    # Signature
    signed_by = fields.Char(copy=False, readonly=True)
    signed_on = fields.Datetime(copy=False, readonly=True)
    signature = fields.Image(copy=False, max_width=1024, max_height=1024, readonly=True)
    require_signature = fields.Boolean(related="stage_id.require_signature")

    def _calc_request_late(self, vals):
        if vals.get("request_early", False):
            early = fields.Datetime.from_string(vals.get("request_early"))
        else:
            early = datetime.now()

        if vals.get("priority") == "0":
            vals["request_late"] = early + timedelta(
                hours=self.env.company.fsm_order_request_late_lowest
            )
        elif vals.get("priority") == "1":
            vals["request_late"] = early + timedelta(
                hours=self.env.company.fsm_order_request_late_low
            )
        elif vals.get("priority") == "2":
            vals["request_late"] = early + timedelta(
                hours=self.env.company.fsm_order_request_late_medium
            )
        elif vals.get("priority") == "3":
            vals["request_late"] = early + timedelta(
                hours=self.env.company.fsm_order_request_late_high
            )
        return vals

    request_late = fields.Datetime(string="Latest Request Date")
    description = fields.Html(
        compute="_compute_description",
        precompute=True,
        store=True,
        readonly=False,
    )

    person_ids = fields.Many2many("fsm.person", string="Field Service Workers")

    # Planning
    person_id = fields.Many2one("fsm.person", string="Assigned To", index=True)
    person_phone = fields.Char(related="person_id.phone", string="Worker Phone")
    scheduled_date_start = fields.Datetime(string="Scheduled Start (ETA)")
    scheduled_duration = fields.Float(help="Scheduled duration of the work in hours")
    scheduled_date_end = fields.Datetime(string="Scheduled End")
    sequence = fields.Integer(default=10)
    todo = fields.Html(
        string="Instructions",
        compute="_compute_todo",
        precompute=True,
        store=True,
        readonly=False,
    )

    # Execution
    resolution = fields.Html()
    date_start = fields.Datetime(string="Actual Start")
    date_end = fields.Datetime(string="Actual End")
    duration = fields.Float(
        string="Actual duration",
        compute="_compute_duration",
        help="Actual duration in hours",
    )
    current_date = fields.Datetime(default=fields.Datetime.now, store=True)

    # Location
    territory_id = fields.Many2one(
        "res.territory",
        string="Territory",
        related="location_id.territory_id",
        store=True,
    )
    branch_id = fields.Many2one(
        "res.branch", string="Branch", related="location_id.branch_id", store=True
    )
    district_id = fields.Many2one(
        "res.district", string="District", related="location_id.district_id", store=True
    )
    region_id = fields.Many2one(
        "res.region", string="Region", related="location_id.region_id", store=True
    )

    # Fields for Geoengine Identify
    display_name = fields.Char(related="name", string="Order")
    street = fields.Char(related="location_id.street")
    street2 = fields.Char(related="location_id.street2")
    zip = fields.Char(related="location_id.zip")
    city = fields.Char(related="location_id.city")
    state_name = fields.Char(related="location_id.state_id.name", string="State")
    country_name = fields.Char(related="location_id.country_id.name", string="Country")
    phone = fields.Char(related="location_id.phone", string="Location Phone")

    stage_name = fields.Char(related="stage_id.name", string="Stage Name")
    # Field for Stage Color
    custom_color = fields.Char(related="stage_id.custom_color", string="Stage Color")

    # Template
    template_id = fields.Many2one("fsm.template", string="Template")
    category_ids = fields.Many2many("fsm.category", string="Categories")
    equipment_ids = fields.Many2many(
        "fsm.equipment",
        string="Equipments",
        compute="_compute_equipment_ids",
        precompute=True,
        store=True,
        readonly=False,
    )
    type = fields.Many2one("fsm.order.type")

    internal_type = fields.Selection(related="type.internal_type")

    @api.depends("company_id")
    def _compute_equipment_ids(self):
        for rec in self:
            # Clear equipments that no longer match the order company
            to_remove = rec.equipment_ids.filtered(
                lambda equipment, rec=rec: equipment.company_id != rec.company_id
            )
            if to_remove:
                rec.equipment_ids = [
                    Command.unlink(equipment.id) for equipment in to_remove
                ]
            # If we have no equipments, auto populate if needed
            if (
                rec.company_id.auto_populate_equipments_on_order
                and not rec.equipment_ids
            ):
                rec.equipment_ids = self.env["fsm.equipment"].search(
                    domain=Domain.AND(
                        [
                            Domain("current_location_id", "=", rec.location_id.id),
                            Domain("company_id", "=", rec.company_id.id),
                        ]
                    )
                )

    @api.depends("location_id")
    def _compute_location_directions(self):
        for rec in self:
            rec.location_directions = rec.location_id.complete_direction

    @api.depends("template_id")
    def _compute_todo(self):
        for rec in self:
            if rec.template_id:
                rec.todo = rec.template_id.instructions

    @api.depends("equipment_ids", "type")
    def _compute_description(self):
        for rec in self:
            if rec.description:
                continue
            rec.description = Markup("<separator />").join(
                equipment.notes for equipment in rec.equipment_ids if equipment.notes
            )

    @api.model
    def _read_group_stage_ids(self, stages, domain, order=None):
        search_domain = Domain("stage_type", "=", "order")
        if self.env.context.get("default_team_id"):
            search_domain = Domain.AND(
                [
                    Domain("team_ids", "in", self.env.context["default_team_id"]),
                    search_domain,
                ]
            )
        return stages.search(search_domain, order=order)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", self.env._("New")) == self.env._("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "fsm.order"
                ) or self.env._("New")
            self._calc_scheduled_dates(vals)
            if not vals.get("request_late"):
                vals = self._calc_request_late(vals)
        return super().create(vals_list)

    def write(self, vals):
        if (
            not self.env.context.get("bypass_order_completed_stage")
            and (stage_id := vals.get("stage_id"))
            and stage_id == self.env.ref("fieldservice.fsm_stage_completed").id
        ):
            raise UserError(self.env._("Cannot move to completed from Kanban"))
        self._calc_scheduled_dates(vals)
        res = super().write(vals)
        return res

    def can_unlink(self):
        """:return True if the order can be deleted, False otherwise"""
        return self.stage_id == self._default_stage_id()

    @api.ondelete(at_uninstall=False)
    def _unlink_if_not_default_stage(self):
        if not all(order.can_unlink() for order in self):
            raise ValidationError(self.env._("You cannot delete this order."))

    def _calc_scheduled_dates(self, vals):
        """Calculate scheduled dates and duration"""

        if (
            vals.get("scheduled_duration") is not None
            or vals.get("scheduled_date_start")
            or vals.get("scheduled_date_end")
        ):
            if vals.get("scheduled_date_start") and vals.get("scheduled_date_end"):
                new_date_start = fields.Datetime.from_string(
                    vals.get("scheduled_date_start", False)
                )
                new_date_end = fields.Datetime.from_string(
                    vals.get("scheduled_date_end", False)
                )
                hours = new_date_end.replace(second=0) - new_date_start.replace(
                    second=0
                )
                hrs = hours.total_seconds() / 3600
                vals["scheduled_duration"] = float(hrs)

            elif vals.get("scheduled_date_end"):
                hrs = (
                    vals.get("scheduled_duration", False)
                    or self.scheduled_duration
                    or 0
                )
                date_to_with_delta = fields.Datetime.from_string(
                    vals.get("scheduled_date_end", False)
                ) - timedelta(hours=hrs)
                vals["scheduled_date_start"] = str(date_to_with_delta)

            elif (
                vals.get("scheduled_duration", False) is not None
                and vals.get("scheduled_date_start", self.scheduled_date_start)
                and (
                    self.scheduled_date_start != vals.get("scheduled_date_start", False)
                )
            ):
                hours = vals.get("scheduled_duration", False)
                start_date_val = vals.get(
                    "scheduled_date_start", self.scheduled_date_start
                )
                start_date = fields.Datetime.from_string(start_date_val)
                date_to_with_delta = start_date + timedelta(hours=hours)
                vals["scheduled_date_end"] = str(date_to_with_delta)
        elif vals.get("scheduled_date_start") is not None:
            vals["scheduled_date_end"] = False

    def action_complete(self):
        return self.with_context(bypass_order_completed_stage=True).write(
            {
                "stage_id": self.env.ref("fieldservice.fsm_stage_completed").id,
            }
        )

    def action_cancel(self):
        return self.write(
            {"stage_id": self.env.ref("fieldservice.fsm_stage_cancelled").id}
        )

    @api.onchange("scheduled_date_end")
    def onchange_scheduled_date_end(self):
        if self.scheduled_date_end:
            date_to_with_delta = fields.Datetime.from_string(
                self.scheduled_date_end
            ) - timedelta(hours=self.scheduled_duration)
            self.date_start = str(date_to_with_delta)

    @api.onchange("scheduled_date_start", "scheduled_duration")
    def onchange_scheduled_duration(self):
        if self.scheduled_duration and self.scheduled_date_start:
            date_to_with_delta = fields.Datetime.from_string(
                self.scheduled_date_start
            ) + timedelta(hours=self.scheduled_duration)
            self.scheduled_date_end = str(date_to_with_delta)
        else:
            self.scheduled_date_end = self.scheduled_date_start

    @api.onchange("template_id")
    def _onchange_template_id(self):
        if self.template_id:
            self.category_ids = self.template_id.category_ids
            self.scheduled_duration = self.template_id.duration
            if self.template_id.type_id:
                self.type = self.template_id.type_id
            if self.template_id.team_id:
                self.team_id = self.template_id.team_id

    @api.onchange("person_id")
    def _onchange_person_id(self):
        if self.person_id and self.person_id.team_id:
            self.team_id = self.person_id.team_id

    @api.constrains("scheduled_date_start")
    def check_day(self):
        for rec in self:
            if not rec.scheduled_date_start:
                continue

            holidays = self.env["resource.calendar.leaves"].search(
                domain=Domain.AND(
                    [
                        Domain("date_from", ">=", rec.scheduled_date_start),
                        Domain("date_to", "<=", rec.scheduled_date_end),
                    ]
                )
            )
            if holidays:
                msg = (
                    f"{rec.scheduled_date_start.date()} is a holiday {holidays[0].name}"
                )
                raise ValidationError(self.env._(msg))
