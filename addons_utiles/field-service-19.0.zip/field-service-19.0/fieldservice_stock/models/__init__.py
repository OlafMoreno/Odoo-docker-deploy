# Copyright (C) 2018 - TODAY, Brian McMaster
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from . import (
    res_territory,
    fsm_location,
    fsm_order,
    stock_move,
    stock_reference,
    stock_rule,
    stock_picking,
    fsm_person,
)
