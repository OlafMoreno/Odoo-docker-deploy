# Copyright (C) 2019, Gray Matter Logic
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import fields, models


class FSMStage(models.Model):
    _inherit = "fsm.stage"

    action_id = fields.Many2one("ir.actions.server", string="Server Action")
